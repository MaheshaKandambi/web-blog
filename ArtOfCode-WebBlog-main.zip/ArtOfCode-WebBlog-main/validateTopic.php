<?php 
function validateTopic($topic)
{ 
    $errors=array();
    if(empty($topic['name'])){
        
        array_push($errors, 'Title is required');
    }
    if(empty($topic['description'])){
        
        array_push($errors, 'Body is required');
    }
    $existingTopic = selectOne('topics', ['name'=>$_POST['name']]);
    if($existingTopic){
      
        array_push($errors, "Post with that title already exists");

    }
    return $errors;
}
?>