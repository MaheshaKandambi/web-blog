<?php

define("ROOT_PATH", realpath(dirname(__FILE__)));
// var_dump(ROOT_PATH);
?>