<?php
    $host='localhost';
    $user='root';
    $password='';
    $db_name='artofcode';

    $connect = new mysqli($host, $user, $password, $db_name);
    if($connect->connect_error){
        die('Database connection error: '.$connect->connect_error);
    }
    else{
        // echo 'Database connection successful!';
    }