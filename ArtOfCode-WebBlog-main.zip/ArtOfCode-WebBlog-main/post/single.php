<?php include('C:\Xampp\htdocs\Karmanta-lite\posts.php');
    if(isset($_GET['id'])){
        $post=selectOne('posts',['id'=>$_GET['id']]);
        
    }
    $topics=selectALL('topics');
    $posts = selectAll('posts', ['published'=>1]);
?>
<!DOCTYPE html>
<html lang="en">
<head>

     <title><?php echo $post['title'];?>|ArtOfCode </title>

     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/aos.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/tooplate-gymso-style.css">
     <link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body data-spy="scroll" data-target="#navbarNav" data-offset="50">

    <!-- MENU BAR -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">

            <a class="navbar-brand" href="index.html">Art OF Code</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-lg-auto">
                    <li class="nav-item">
                        <a href="#home" class="nav-link smoothScroll">Home</a>
                    </li>

                    <li class="nav-item">
                        <a href="#about" class="nav-link smoothScroll">About Us</a>
                    </li>

                    <li class="nav-item">
                        <a href="#class" class="nav-link smoothScroll">Classes</a>
                    </li>

                    <li class="nav-item">
                        <a href="#schedule" class="nav-link smoothScroll">Schedules</a>
                    </li>

                    <li class="nav-item">
                        <a href="#contact" class="nav-link smoothScroll">Contact</a>
                    </li>
                </ul>

                <ul class="social-icon ml-lg-3">
                    <li><a href="https://fb.com/tooplate" class="fa fa-facebook"></a></li>
                    <li><a href="#" class="fa fa-twitter"></a></li>
                    <li><a href="#" class="fa fa-instagram"></a></li>
                </ul>
                <ul>
                	<li><a href="#" class="Logout">Logout</a></li>
                </ul>
            </div>

        </div>
    </nav>
    <br><br><br>

    <div class="page-wrapper">
	    
<!-- content-->
    <div class="content clearfix">
<!-- main content-->
    	<div class="main-content single">
         <h1 class="post-title"><?php echo $post['title'];?></h1> 
         <div class="post-content">
            <?php echo html_entity_decode($post['body'])?>
         </div>  
        </div>
<!-- end main content-->
    	<div class="sidebar single">
            <div class="section popular">
                <h2 class="section-title">Popular</h2>
                <?php foreach($posts as $p):?>
                <div class="post clearfix">
                    <img src="<?php echo 'image/'.$p['image'];?>" alt="">
                    <a href="" class="title">
                        <h4><?php echo $p['title']?></h4>
                    </a>  
                </div>
                <?php endforeach;?>
                
            </div>
    		
    		
    		<div class="section topics">
    			<h4 class="section-title">Topics</h4>
    			<ul>
    				
    				<?php foreach($topics as $key=>$topic):?>
                        <li><a href="<?php echo 'post.php?t_id='.$topic['id'].'&name='.$topic['name']?>"><?php echo $topic['name']?></a></li>
                    <?php endforeach;?>
    			</ul>
    		</div>



    	</div>


    </div>

    </div>

     <!-- <div class="footer">
        <div class="footer-content">
            <div class="footer-section about">
                <h3 class="logo-text"><span>Art OF Code</span></h3><br>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat.
                <br>
                </p>
                <div class="contact">
                    <span><a href="#"><i class="fa fa-phone"></i> &nbsp;1234-467-788</a></span>
                    <span><a href=""><i class="fa fa-envelope"></i> &nbsp;info@artofcodes.com</a></span>
                    
                </div>
            </div>
            <div class="footer-section links">
                <h3>Quick Links</h3><br>
                <ul>
                    <a href="#"><li>Events</li></a>
                    <a href="#"><li>Team</li></a>
                    <a href="#"><li>Mentors</li></a>
                    <a href="#"><li>Gallery</li></a>
                    <a href="#"><li>Enents</li></a>
                    <a href="#"><li>Terms and conditions</li></a>

                </ul>
            </div> 



            <div class="footer-section contact-form">
                <h3>Coment us</h3><br>
                <form action="https://formspree.io/f/mrgodbgq" class="contact" method="post">
                <input type="text" name="name" class="text-box contact-input" placeholder="your name" required><br>
                <input type="email" name="email" class="text-box contact-input" placeholder="your Email" required><br>
                <textarea name="message" class="text-box contact-input"  rows="5" placeholder="your message" required></textarea><br>
                <input type="submit" name="submit" class="btn btn-big contact-btn" value="Send">
                </form>
    

            </div>
            
        </div>
        <div class="footer-bottom">
            &copy;codingpoets.com | design by.....
        </div>
    </div>

    -->
   
     <!-- SCRIPTS -->
     <script src="js/jquery.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/aos.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<!--slick carousel-->
     <script src="js/custom.js"></script>
  

</body>
</html>