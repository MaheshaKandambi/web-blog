<?php

    require('connect.php');
    //selectAll
//    function selectALL($table){

//     global $connect;
//     $sql= " SELECT * FROM $table";
//     $statement=$connect->prepare($sql);
//     $statement->execute();
//     $records=$statement->get_result()->fetch_all(MYSQLI_ASSOC);
//    }
function dd($value){
    echo "<pre>", print_r($value,true),"</pre>";
    die();
}
function executeQuery($sql,$data){
    global $connect;
    $statement=$connect->prepare($sql);
    $values = array_values($data);
    $types=str_repeat('s',count($values));
    $statement->bind_param($types, ...$values);
    $statement->execute();
    return $statement;
}
   //select with condition
   function selectALL($table, $conditions=[]){

    global $connect;
    $sql= " SELECT * FROM $table";
    if(empty($conditions)){
        $statement=$connect->prepare($sql);
        $statement->execute();
        $records=$statement->get_result()->fetch_all(MYSQLI_ASSOC);
        return $records;
    }
    else{
        $i=0;
        foreach($conditions as $key => $value){
            if($i==0){
                $sql=$sql ." WHERE $key=?";
                      
        }
        else{
            $sql=$sql." AND $key=?";
        }
        $i++;
    }
    $statement=executeQuery($sql,$conditions);
    $records=$statement->get_result()->fetch_all(MYSQLI_ASSOC);
    return $records;
   }
   }
   //SelectOne
   function selectOne($table, $conditions=[]){

    global $connect;
    $sql= " SELECT * FROM $table";
    {
        $i=0;
        foreach($conditions as $key => $value){
            if($i==0){
                $sql=$sql ." WHERE $key=?";
                      
        }
        else{
            $sql=$sql." AND $key=?";
        }
        $i++;
    }
    $sql=$sql." LIMIT 1";
    $statement=executeQuery($sql,$conditions);
    $records=$statement->get_result()->fetch_assoc();
    return $records;
   
   }
}
//Create function
function create($table, $data)
{
    global $connect;
    $sql="INSERT INTO $table SET ";
    $i=0;
    foreach($data as $key => $value){
        if($i==0){
            $sql=$sql." $key=?";  }
    
    else{
        $sql=$sql.", $key=?";
    }
    $i++;
}
    $statement=executeQuery($sql,$data);
    $id=$statement->insert_id;
    return $id;
}
//UpdateFunction

function update($table,$id,$data)
{
    global $connect;
    $sql="UPDATE $table SET ";
    $i=0;
    foreach($data as $key => $value){
        if($i==0){
            $sql=$sql." $key=?";   }
    
    else{
        $sql=$sql.", $key=?";
    }
    $i++;
}

    $sql= $sql." WHERE id=?";
    $data['$id']=$id;
    $statement=executeQuery($sql,$data);
    return $statement->affected_rows;
}
//DeleteFunction
function delete($table,$id)
{   
    global $connect;
    $sql="DELETE FROM $table WHERE id=?" ;
    
    $statement=executeQuery($sql,['id'=>$id]);
    return $statement->affected_rows;
}
//Search
function searchPosts($term)
{
    $match = '%'.$term.'%';
    global $connect;
    $sql="SELECT * FROM posts AS p  WHERE p.published=? AND p.title LIKE ? or p.body LIKE ?";

    $stmt=executeQuery($sql, ['published'=>1, 'title'=>$match, 'body'=>$match]);
    $records=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    return $records;
}
function getPosts($topic_id)
{
  
    global $connect;
    $sql="SELECT * FROM posts AS p  WHERE p.published=? AND topic_id=?";
    $stmt=executeQuery($sql, ['published'=>1, 'topic_id'=>$topic_id]);
    $records=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    return $records;
}
// $data=[
//     'title'=> 'po',
//     'body'=> 'lkj'
// ];

// $id=create('posts',$data);
// dd($id);