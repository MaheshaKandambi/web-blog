<?php
    require ("dbs.php");
     
    $table ='draft';
   

    $posts= selectALLs($table);
    
    
    $id="";
    $title ="";
    $body = "";

    if (isset($_GET['id'])){
        $post = selectOnes($table, ['id'=>$_GET['id']]);
        //dd($post);
        $id=$post['id'];
        $title =$post['title'];
        $body = $post['body'];
        
    }
    //Delete Post
    if (isset($_GET['delete_id'])){
        $count = deletes($table, $_GET['delete_id']);
        $_SESSION['message']="Post deleted Successfully";
        $_SESSION['type']="success";
        header("location:"."draft.php");
        
    }
    //Add Post
    if(isset($_POST['save-post'])){
         
            $image_name=time(). '_' .$_FILES['image']['name'];
            $destination="assets/images".$image_name;

            $result = move_uploaded_file($_FILES['image']['tmp_name'], $destination);
            if($result){
                $_POST['image']=$image_name;
            }
            
    
        unset($_POST['save-post']);
        $post_id = creates($table, $_POST);
        $_SESSION['message']="Post Created Successfully";
        $_SESSION['type']="success";
        header("location:"."draft.php");
        
    }
    //Update Post
    if(isset($_POST['savefor-post'])){
       
        
       
            $image_name=time(). '_' .$_FILES['image']['name'];
            $destination="assets/images".$image_name;

            $result = move_uploaded_file($_FILES['image']['tmp_name'], $destination);
            if($result){
                $_POST['image']=$image_name;
            }
            
        
            $id=$_POST['id'];
            unset($_POST['savefor-post'],$_POST['id']);
            

            $post_id = updates($table,$id,$_POST);
            $_SESSION['message']="Post Created Successfully";
            $_SESSION['type']="success";
            header("location:"."draft.php");
         
    }
//     //Save Post
//     if(isset($_POST['add-post'])){
        
      
//            $image_name=time(). '_' .$_FILES['image']['name'];
//            $destination="assets/images".$image_name;

//            $result = move_uploaded_file($_FILES['image']['tmp_name'], $destination);
//            if($result){
//                $_POST['image']=$image_name;
//            }
   
//      unset($_POST['save-post']);
//        $post_id = create($table, $_POST);
//        $_SESSION['message']="Post Created Successfully";
//        $_SESSION['type']="success";
//        header("location:"."draft.php");
        
       
//    }
//    //save for later
//    if(isset($_POST['savefor-post'])){
        
//     $image_name=time(). '_' .$_FILES['image']['name'];
//     $destination="assets/images".$image_name;

//     $result = move_uploaded_file($_FILES['image']['tmp_name'], $destination);
//     if($result){
//         $_POST['image']=$image_name;

//    unset($_POST['savefor-post']);
//    $post_id = create($table, $_POST);
//    $_SESSION['message']="Post saved Successfully";
//    $_SESSION['type']="success";
//    header("location:"."draft.php");
//     }
// }
//     ?>